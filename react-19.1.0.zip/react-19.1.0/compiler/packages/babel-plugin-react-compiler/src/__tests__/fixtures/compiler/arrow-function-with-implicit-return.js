// @compilationMode(infer)
const Test = () => <div />;

export const FIXTURE_ENTRYPOINT = {
  fn: Test,
  params: [{}],
};
